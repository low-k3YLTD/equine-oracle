# Equine Oracle MVP Frontend

This is a demo-ready React + TypeScript PWA shell for the Equine Oracle live swarm interface.

## What it does

- Renders a green RTS-style sensor grid inspired by your reference.
- Animates five red swarm agents harvesting yellow prediction orbs.
- Shows a black Kelly controller cube in the center of the board.
- Shows a purple semantic node that reveals live reasoning.
- Connects to `POST /api/v2/predict` and gracefully falls back to demo data when the backend is unavailable.
- Works well on mobile screens and can be installed as a PWA on Android.

## Quick start

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`.

## Backend contract

The frontend posts to `/api/v2/predict` with this payload:

```json
{
  "bankroll": 1000,
  "limit": 5,
  "include_explanations": true,
  "surface": "all"
}
```

Expected response shape:

```json
{
  "regime": "stable",
  "volatility": 0.14,
  "kellyFraction": 0.055,
  "drawdown": 0.03,
  "grokInsight": "Track bias is shifting toward closers.",
  "predictions": [
    {
      "id": "r7-signal-runner",
      "race": "Race 7",
      "horse": "Signal Runner",
      "edge": 12.4,
      "confidence": 0.84,
      "odds": 4.8,
      "bankrollDelta": 61,
      "semanticSummary": "Late pace + soft track profile fit the current regime."
    }
  ]
}
```

## Notes

- Vite dev server proxies `/api/*` to `http://localhost:8000`.
- If you want Android packaging next, this frontend is ready to be wrapped with Capacitor.
