# Equine Oracle — Instant Frontend Setup

## 1) Clone your repo

```bash
git clone https://github.com/lowkey-consultants/equine-oracle.git
cd equine-oracle
```

## 2) Install the frontend

```bash
cd frontend
npm install
npm run dev
```

## 3) Run with the live API

The app calls:

- `POST /api/v2/predict`

During local development, Vite proxies `/api/*` to `http://localhost:8000`.

## 4) Build for production

```bash
npm run build
npm run preview
```

## 5) Android / PWA demo path

- Open the site in Chrome on Android.
- Use “Add to Home screen”.
- Or wrap the frontend with Capacitor for Play Store packaging.
