export type Regime = 'stable' | 'volatile' | 'chaotic';

export type AgentType =
  | 'BACKEND_ML'
  | 'FRONTEND'
  | 'ANDROID'
  | 'ADMIN'
  | 'RESEARCH';

export interface AgentConfig {
  name: string;
  color: string;
  accent: string;
  icon: string;
}

export interface Agent {
  id: string;
  type: AgentType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  carryingOrbId: string | null;
  trail: Array<{ x: number; y: number }>;
}

export interface PredictionOrb {
  id: string;
  x: number;
  y: number;
  race: string;
  horse: string;
  edge: number;
  confidence: number;
  odds: number;
  bankrollDelta: number;
  semanticSummary: string;
  pickedBy: string | null;
  resolved: boolean;
  createdAt: number;
}

export interface PredictApiPrediction {
  id?: string;
  race?: string;
  horse?: string;
  edge?: number;
  confidence?: number;
  odds?: number;
  bankrollDelta?: number;
  semanticSummary?: string;
}

export interface PredictApiResponse {
  predictions?: PredictApiPrediction[];
  regime?: Regime;
  volatility?: number;
  kellyFraction?: number;
  drawdown?: number;
  grokInsight?: string;
}

export interface OracleTelemetry {
  bankroll: number;
  peakBankroll: number;
  drawdown: number;
  regime: Regime;
  volatility: number;
  kellyFraction: number;
  grokInsight: string;
  demoMode: boolean;
  lastSyncLabel: string;
}
