import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { fetchPredictions } from '../lib/api';
import { Agent, AgentType, OracleTelemetry, PredictionOrb } from '../types';

export const GRID_SIZE = 20;
export const CELL_SIZE = 32;
export const BASE_COORDS = { x: GRID_SIZE / 2, y: GRID_SIZE / 2 };
export const SEMANTIC_NODE = { x: GRID_SIZE - 3.25, y: 3.5 };

export const AGENT_CONFIG: Record<AgentType, { name: string; color: string; accent: string; icon: string }> = {
  BACKEND_ML: { name: 'ML Engine', color: '#ff325f', accent: '#ff8fa6', icon: '●' },
  FRONTEND: { name: 'Dashboard', color: '#ff4973', accent: '#ffb3c2', icon: '●' },
  ANDROID: { name: 'Mobile Intel', color: '#e11d48', accent: '#ff8aac', icon: '●' },
  ADMIN: { name: 'Admin Panel', color: '#be123c', accent: '#fca5b8', icon: '●' },
  RESEARCH: { name: 'Research Lab', color: '#fb7185', accent: '#fecdd6', icon: '●' }
};

const INITIAL_TELEMETRY: OracleTelemetry = {
  bankroll: 1000,
  peakBankroll: 1000,
  drawdown: 0,
  regime: 'stable',
  volatility: 0.12,
  kellyFraction: 0.055,
  grokInsight: 'Tap the semantic node to unpack why the current swarm likes these runners.',
  demoMode: true,
  lastSyncLabel: 'waiting...'
};

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function createSeedAgents(): Agent[] {
  const entries = Object.keys(AGENT_CONFIG) as AgentType[];

  return entries.map((type, index) => ({
    id: `agent-${type.toLowerCase()}`,
    type,
    x: BASE_COORDS.x + Math.cos((Math.PI * 2 * index) / entries.length) * 2.2,
    y: BASE_COORDS.y + Math.sin((Math.PI * 2 * index) / entries.length) * 2.2,
    vx: (Math.random() - 0.5) * 0.5,
    vy: (Math.random() - 0.5) * 0.5,
    carryingOrbId: null,
    trail: []
  }));
}

function computeDrawdown(bankroll: number, peakBankroll: number) {
  if (peakBankroll <= 0) return 0;
  return Math.max(0, (peakBankroll - bankroll) / peakBankroll);
}

export function useOracleGame() {
  const [agents, setAgents] = useState<Agent[]>(() => createSeedAgents());
  const [orbs, setOrbs] = useState<PredictionOrb[]>([]);
  const [telemetry, setTelemetry] = useState<OracleTelemetry>(INITIAL_TELEMETRY);

  const agentsRef = useRef(agents);
  const orbsRef = useRef(orbs);
  const telemetryRef = useRef(telemetry);
  const syncingRef = useRef(false);

  useEffect(() => {
    agentsRef.current = agents;
  }, [agents]);

  useEffect(() => {
    orbsRef.current = orbs;
  }, [orbs]);

  useEffect(() => {
    telemetryRef.current = telemetry;
  }, [telemetry]);

  const applyBankrollGain = useCallback((gain: number, insight?: string) => {
    const bankroll = telemetryRef.current.bankroll + gain;
    const peakBankroll = Math.max(telemetryRef.current.peakBankroll, bankroll);
    const nextTelemetry = {
      ...telemetryRef.current,
      bankroll,
      peakBankroll,
      drawdown: computeDrawdown(bankroll, peakBankroll),
      grokInsight: insight ?? telemetryRef.current.grokInsight
    };

    telemetryRef.current = nextTelemetry;
    setTelemetry(nextTelemetry);
  }, []);

  const syncPredictions = useCallback(async () => {
    if (syncingRef.current) return;
    syncingRef.current = true;

    const result = await fetchPredictions(telemetryRef.current.bankroll);
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const nextTelemetry: OracleTelemetry = {
      ...telemetryRef.current,
      regime: result.telemetry.regime ?? telemetryRef.current.regime,
      volatility: result.telemetry.volatility ?? telemetryRef.current.volatility,
      kellyFraction: result.telemetry.kellyFraction ?? telemetryRef.current.kellyFraction,
      drawdown: result.telemetry.drawdown ?? telemetryRef.current.drawdown,
      grokInsight: result.telemetry.grokInsight ?? telemetryRef.current.grokInsight,
      demoMode: result.demoMode,
      lastSyncLabel: timestamp
    };

    const merged = [...orbsRef.current];
    for (const orb of result.predictions) {
      if (!merged.some((existing) => existing.id === orb.id)) {
        merged.push(orb);
      }
    }

    const trimmed = merged
      .filter((orb) => !orb.resolved)
      .sort((a, b) => b.confidence * b.edge - a.confidence * a.edge)
      .slice(0, 10);

    orbsRef.current = trimmed;
    telemetryRef.current = nextTelemetry;
    setOrbs(trimmed);
    setTelemetry(nextTelemetry);
    syncingRef.current = false;
  }, []);

  const claimOrb = useCallback(
    (orbId: string) => {
      const orb = orbsRef.current.find((entry) => entry.id === orbId);
      if (!orb) return;

      const remaining = orbsRef.current.filter((entry) => entry.id !== orbId);
      orbsRef.current = remaining;
      setOrbs(remaining);
      applyBankrollGain(orb.bankrollDelta, orb.semanticSummary);
    },
    [applyBankrollGain]
  );

  useEffect(() => {
    syncPredictions();

    const syncTimer = window.setInterval(() => {
      syncPredictions();
    }, 9000);

    const frameTimer = window.setInterval(() => {
      const pool = [...orbsRef.current];
      let bankrollGain = 0;
      let latestInsight = telemetryRef.current.grokInsight;

      const nextAgents = agentsRef.current.map((agent) => {
        let { x, y, vx, vy, carryingOrbId } = agent;
        let trail = [...agent.trail];
        const carriedIndex = carryingOrbId ? pool.findIndex((orb) => orb.id === carryingOrbId) : -1;
        const carriedOrb = carriedIndex >= 0 ? pool[carriedIndex] : null;

        let targetX = BASE_COORDS.x;
        let targetY = BASE_COORDS.y;

        if (carriedOrb) {
          targetX = BASE_COORDS.x;
          targetY = BASE_COORDS.y;
        } else {
          carryingOrbId = null;
          const availableOrbs = pool.filter((orb) => !orb.pickedBy || orb.pickedBy === agent.id);
          if (availableOrbs.length > 0) {
            const nearest = availableOrbs.reduce((best, orb) => {
              const distance = Math.hypot(orb.x - x, orb.y - y);
              const bestDistance = Math.hypot(best.x - x, best.y - y);
              return distance < bestDistance ? orb : best;
            });
            targetX = nearest.x;
            targetY = nearest.y;
          } else {
            targetX = SEMANTIC_NODE.x;
            targetY = SEMANTIC_NODE.y;
          }
        }

        const dx = targetX - x;
        const dy = targetY - y;
        const distance = Math.max(0.0001, Math.hypot(dx, dy));

        vx += (dx / distance) * (carriedOrb ? 0.05 : 0.08);
        vy += (dy / distance) * (carriedOrb ? 0.05 : 0.08);

        const speed = Math.hypot(vx, vy);
        const speedCap = carriedOrb ? 0.46 : 0.62;
        if (speed > speedCap) {
          vx = (vx / speed) * speedCap;
          vy = (vy / speed) * speedCap;
        }

        x = clamp(x + vx, 0.6, GRID_SIZE - 0.6);
        y = clamp(y + vy, 0.6, GRID_SIZE - 0.6);

        if (!carriedOrb) {
          const lockOn = pool.find((orb) => Math.hypot(orb.x - x, orb.y - y) < 0.7 && (!orb.pickedBy || orb.pickedBy === agent.id));
          if (lockOn) {
            lockOn.pickedBy = agent.id;
            carryingOrbId = lockOn.id;
          }
        } else {
          carriedOrb.x = x;
          carriedOrb.y = y;
          carriedOrb.pickedBy = agent.id;
          const baseDistance = Math.hypot(BASE_COORDS.x - x, BASE_COORDS.y - y);
          if (baseDistance < 0.95) {
            bankrollGain += carriedOrb.bankrollDelta;
            latestInsight = carriedOrb.semanticSummary;
            pool.splice(carriedIndex, 1);
            carryingOrbId = null;
          }
        }

        trail.push({ x, y });
        if (trail.length > 10) trail = trail.slice(-10);

        return {
          ...agent,
          x,
          y,
          vx,
          vy,
          carryingOrbId,
          trail
        };
      });

      agentsRef.current = nextAgents;
      orbsRef.current = pool;
      setAgents(nextAgents);
      setOrbs([...pool]);

      if (bankrollGain > 0) {
        applyBankrollGain(bankrollGain, latestInsight);
      }
    }, 60);

    return () => {
      window.clearInterval(syncTimer);
      window.clearInterval(frameTimer);
    };
  }, [applyBankrollGain, syncPredictions]);

  const rankedOrbs = useMemo(
    () => [...orbs].sort((a, b) => b.confidence * b.edge - a.confidence * a.edge),
    [orbs]
  );

  return {
    agents,
    orbs: rankedOrbs,
    telemetry,
    claimOrb,
    syncPredictions,
    baseCoords: BASE_COORDS,
    semanticNode: SEMANTIC_NODE
  };
}
