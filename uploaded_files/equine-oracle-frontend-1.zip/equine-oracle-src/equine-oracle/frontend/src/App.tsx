import EquineOracleRTS from './components/EquineOracleRTS';

export default function App() {
  return <EquineOracleRTS />;
}
