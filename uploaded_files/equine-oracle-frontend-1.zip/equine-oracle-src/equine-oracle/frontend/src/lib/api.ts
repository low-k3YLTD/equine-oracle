import { PredictApiResponse, PredictionOrb, Regime } from '../types';

const HORSES = [
  'Northern Static',
  'Velvet Rail',
  'Silver Paradox',
  'Track Alchemist',
  'Signal Runner',
  'Midnight Split',
  'Quantum Filly',
  'Bankroll Baron'
];

const INSIGHTS = [
  'Meta-ensemble convergence is rising across late-speed runners.',
  'Track bias is tilting toward closers after the moisture shift.',
  'Pool inefficiency detected in quinella and exacta ladders.',
  'Kelly controller is compressing stake size due to volatility clustering.',
  'Regime memory suggests a temporary edge on horses with soft-track stamina.'
];

function randomBetween(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function buildMockPrediction(index: number): PredictionOrb {
  const confidence = randomBetween(0.58, 0.93);
  const edge = randomBetween(3, 18);
  const odds = randomBetween(2.1, 8.4);
  const bankrollDelta = Math.round(randomBetween(18, 96));

  return {
    id: `mock-${Date.now()}-${index}-${Math.round(Math.random() * 9999)}`,
    x: randomBetween(2, 18),
    y: randomBetween(2, 18),
    race: `Race ${Math.ceil(randomBetween(1, 9))}`,
    horse: HORSES[Math.floor(Math.random() * HORSES.length)],
    edge,
    confidence,
    odds,
    bankrollDelta,
    semanticSummary: INSIGHTS[Math.floor(Math.random() * INSIGHTS.length)],
    pickedBy: null,
    resolved: false,
    createdAt: Date.now()
  };
}

function mockResponse(): { telemetry: PredictApiResponse; predictions: PredictionOrb[]; demoMode: boolean } {
  const volatile = Math.random() > 0.72;
  const chaotic = !volatile && Math.random() > 0.88;
  const regime: Regime = chaotic ? 'chaotic' : volatile ? 'volatile' : 'stable';
  const volatility = regime === 'stable' ? randomBetween(0.08, 0.17) : regime === 'volatile' ? randomBetween(0.18, 0.28) : randomBetween(0.29, 0.4);
  const kellyFraction = regime === 'stable' ? 0.055 : regime === 'volatile' ? 0.028 : 0.015;

  return {
    telemetry: {
      regime,
      volatility,
      kellyFraction,
      grokInsight: INSIGHTS[Math.floor(Math.random() * INSIGHTS.length)]
    },
    predictions: Array.from({ length: 5 }, (_, index) => buildMockPrediction(index)),
    demoMode: true
  };
}

export async function fetchPredictions(bankroll: number): Promise<{
  telemetry: PredictApiResponse;
  predictions: PredictionOrb[];
  demoMode: boolean;
}> {
  try {
    const response = await fetch('/api/v2/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        bankroll,
        limit: 5,
        include_explanations: true,
        surface: 'all'
      })
    });

    if (!response.ok) {
      throw new Error(`Predict endpoint failed with status ${response.status}`);
    }

    const payload = (await response.json()) as PredictApiResponse;
    const predictions = (payload.predictions ?? []).slice(0, 5).map((prediction, index) => ({
      id: prediction.id ?? `api-${Date.now()}-${index}`,
      x: randomBetween(2, 18),
      y: randomBetween(2, 18),
      race: prediction.race ?? `Race ${index + 1}`,
      horse: prediction.horse ?? HORSES[index % HORSES.length],
      edge: prediction.edge ?? randomBetween(2, 15),
      confidence: prediction.confidence ?? randomBetween(0.55, 0.9),
      odds: prediction.odds ?? randomBetween(2, 9),
      bankrollDelta: prediction.bankrollDelta ?? Math.round(randomBetween(18, 80)),
      semanticSummary: prediction.semanticSummary ?? INSIGHTS[index % INSIGHTS.length],
      pickedBy: null,
      resolved: false,
      createdAt: Date.now()
    }));

    return {
      telemetry: payload,
      predictions: predictions.length ? predictions : mockResponse().predictions,
      demoMode: false
    };
  } catch (error) {
    console.warn('Falling back to demo prediction stream', error);
    return mockResponse();
  }
}
