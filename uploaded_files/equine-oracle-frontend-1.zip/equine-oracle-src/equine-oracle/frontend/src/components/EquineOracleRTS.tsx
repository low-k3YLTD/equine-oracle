import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Brain,
  DollarSign,
  Sparkles,
  TrendingUp,
  Wifi,
  WifiOff,
  Zap
} from 'lucide-react';
import { AGENT_CONFIG, CELL_SIZE, GRID_SIZE, useOracleGame } from '../hooks/useOracleGame';
import { PredictionOrb } from '../types';

const CANVAS_SIZE = GRID_SIZE * CELL_SIZE;

function formatCurrency(value: number) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  }).format(value);
}

function formatPercent(value: number, digits = 1) {
  return `${(value * 100).toFixed(digits)}%`;
}

export default function EquineOracleRTS() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showSemanticPanel, setShowSemanticPanel] = useState(false);
  const [focusedOrbId, setFocusedOrbId] = useState<string | null>(null);
  const { agents, orbs, telemetry, claimOrb, syncPredictions, baseCoords, semanticNode } = useOracleGame();

  const focusedOrb = useMemo(
    () => orbs.find((orb) => orb.id === focusedOrbId) ?? orbs[0] ?? null,
    [focusedOrbId, orbs]
  );

  useEffect(() => {
    if (!focusedOrb && orbs[0]) {
      setFocusedOrbId(orbs[0].id);
    }
  }, [focusedOrb, orbs]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;

    context.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    const bg = context.createLinearGradient(0, 0, CANVAS_SIZE, CANVAS_SIZE);
    bg.addColorStop(0, '#07150b');
    bg.addColorStop(1, '#0c2b17');
    context.fillStyle = bg;
    context.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    context.strokeStyle = 'rgba(37, 111, 59, 0.55)';
    context.lineWidth = 1;
    for (let index = 0; index <= GRID_SIZE; index += 1) {
      const offset = index * CELL_SIZE;
      context.beginPath();
      context.moveTo(offset, 0);
      context.lineTo(offset, CANVAS_SIZE);
      context.stroke();
      context.beginPath();
      context.moveTo(0, offset);
      context.lineTo(CANVAS_SIZE, offset);
      context.stroke();
    }

    context.strokeStyle = 'rgba(0, 255, 136, 0.15)';
    context.lineWidth = 2;
    orbs.forEach((orb) => {
      context.beginPath();
      context.moveTo(baseCoords.x * CELL_SIZE, baseCoords.y * CELL_SIZE);
      context.lineTo(orb.x * CELL_SIZE, orb.y * CELL_SIZE);
      context.stroke();
    });

    const semanticX = semanticNode.x * CELL_SIZE;
    const semanticY = semanticNode.y * CELL_SIZE;

    context.save();
    context.shadowBlur = 24;
    context.shadowColor = '#9b87f5';
    context.beginPath();
    context.arc(semanticX, semanticY, 16, 0, Math.PI * 2);
    context.fillStyle = '#8b5cf6';
    context.fill();
    context.beginPath();
    context.arc(semanticX, semanticY, 24, 0, Math.PI * 2);
    context.strokeStyle = '#c4b5fd';
    context.lineWidth = 3;
    context.stroke();
    context.restore();

    context.save();
    context.shadowBlur = 30;
    context.shadowColor = '#00ff88';
    const baseX = baseCoords.x * CELL_SIZE;
    const baseY = baseCoords.y * CELL_SIZE;
    context.fillStyle = '#020202';
    context.fillRect(baseX - 18, baseY - 18, 36, 36);
    context.strokeStyle = '#00ff88';
    context.lineWidth = 2.5;
    context.strokeRect(baseX - 18, baseY - 18, 36, 36);
    context.restore();

    context.strokeStyle = 'rgba(192, 198, 208, 0.55)';
    context.lineWidth = 2;
    context.beginPath();
    context.moveTo(semanticX - 20, semanticY + 30);
    context.lineTo(semanticX + 20, semanticY + 10);
    context.lineTo(semanticX + 34, semanticY + 40);
    context.stroke();

    orbs.forEach((orb) => {
      const x = orb.x * CELL_SIZE;
      const y = orb.y * CELL_SIZE;
      const highlighted = orb.id === focusedOrb?.id;
      context.save();
      context.shadowBlur = highlighted ? 28 : 18;
      context.shadowColor = '#ffd84d';
      context.beginPath();
      context.arc(x, y, highlighted ? 12 : 10, 0, Math.PI * 2);
      context.fillStyle = `rgba(255, 216, 77, ${Math.max(0.5, orb.confidence)})`;
      context.fill();
      context.strokeStyle = highlighted ? '#fff5b8' : '#ffd84d';
      context.lineWidth = highlighted ? 3 : 2;
      context.stroke();
      context.restore();
    });

    agents.forEach((agent) => {
      const x = agent.x * CELL_SIZE;
      const y = agent.y * CELL_SIZE;
      const config = AGENT_CONFIG[agent.type];

      context.save();
      context.strokeStyle = `${config.color}55`;
      context.lineWidth = 2;
      context.beginPath();
      agent.trail.forEach((point, index) => {
        const px = point.x * CELL_SIZE;
        const py = point.y * CELL_SIZE;
        if (index === 0) context.moveTo(px, py);
        else context.lineTo(px, py);
      });
      context.stroke();
      context.restore();

      context.save();
      context.translate(x, y);
      context.rotate(Math.atan2(agent.vy, agent.vx));
      context.fillStyle = config.color;
      context.beginPath();
      context.moveTo(10, 0);
      context.lineTo(-6, 5);
      context.lineTo(-6, -5);
      context.closePath();
      context.fill();
      context.strokeStyle = config.accent;
      context.lineWidth = 1.4;
      context.stroke();
      context.restore();

      if (agent.carryingOrbId) {
        context.beginPath();
        context.arc(x, y, 12, 0, Math.PI * 2);
        context.strokeStyle = '#ffd84d';
        context.lineWidth = 2;
        context.stroke();
      }
    });
  }, [agents, baseCoords.x, baseCoords.y, focusedOrb, orbs, semanticNode.x, semanticNode.y]);

  const handleCanvasClick = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_SIZE / rect.width;
    const scaleY = CANVAS_SIZE / rect.height;
    const clickX = (event.clientX - rect.left) * scaleX;
    const clickY = (event.clientY - rect.top) * scaleY;

    const semanticDistance = Math.hypot(clickX - semanticNode.x * CELL_SIZE, clickY - semanticNode.y * CELL_SIZE);
    if (semanticDistance < 28) {
      setShowSemanticPanel((current) => !current);
      return;
    }

    const hitOrb = orbs.find((orb) => Math.hypot(clickX - orb.x * CELL_SIZE, clickY - orb.y * CELL_SIZE) < 18);
    if (hitOrb) {
      setFocusedOrbId(hitOrb.id);
      claimOrb(hitOrb.id);
    }
  };

  const sortedAgents = useMemo(() => Object.entries(AGENT_CONFIG), []);

  return (
    <main className="oracle-shell">
      <section className="hero-panel">
        <div>
          <p className="eyebrow">Equine Oracle // Live Swarm Command</p>
          <h1>Horse-racing intelligence rendered like a real-time strategy organism.</h1>
          <p className="hero-copy">
            The grid is your temporal sensor map. Red swarm agents hunt +EV predictions, the black cube enforces Kelly sizing,
            and the purple semantic node explains why the ensemble likes a runner.
          </p>
        </div>
        <div className="hero-actions">
          <button className="primary-button" onClick={() => syncPredictions()}>
            <Zap size={18} /> Sync /api/v2/predict
          </button>
          <button className="ghost-button" onClick={() => setShowSemanticPanel((current) => !current)}>
            <Brain size={18} /> Grok reasoning
          </button>
        </div>
      </section>

      <section className="status-grid">
        <article className="stat-card">
          <span className="stat-label">Bankroll</span>
          <strong className="stat-value positive">{formatCurrency(telemetry.bankroll)}</strong>
          <small className="stat-meta">Peak {formatCurrency(telemetry.peakBankroll)}</small>
        </article>
        <article className="stat-card">
          <span className="stat-label">Kelly fraction</span>
          <strong className="stat-value amber">{formatPercent(telemetry.kellyFraction, 2)}</strong>
          <small className="stat-meta">Log-wealth + drawdown policy</small>
        </article>
        <article className="stat-card">
          <span className="stat-label">Drawdown</span>
          <strong className={`stat-value ${telemetry.drawdown > 0.1 ? 'danger' : 'positive'}`}>
            {formatPercent(telemetry.drawdown, 1)}
          </strong>
          <small className="stat-meta">Hard brakes above 12%</small>
        </article>
        <article className="stat-card">
          <span className="stat-label">Regime</span>
          <strong className={`stat-value regime regime-${telemetry.regime}`}>{telemetry.regime}</strong>
          <small className="stat-meta">Volatility {formatPercent(telemetry.volatility, 1)}</small>
        </article>
      </section>

      <section className="main-grid">
        <div className="board-card">
          <div className="board-header">
            <div>
              <h2>Temporal-Stratified Sensor Grid</h2>
              <p>Tap a yellow orb to manually claim a high-confidence horse play.</p>
            </div>
            <div className={`sync-pill ${telemetry.demoMode ? 'offline' : 'online'}`}>
              {telemetry.demoMode ? <WifiOff size={15} /> : <Wifi size={15} />}
              {telemetry.demoMode ? 'Demo stream' : `Live @ ${telemetry.lastSyncLabel}`}
            </div>
          </div>
          <canvas
            ref={canvasRef}
            className="oracle-canvas"
            width={CANVAS_SIZE}
            height={CANVAS_SIZE}
            onClick={handleCanvasClick}
          />
          <div className="board-legend">
            <span><i className="legend-swatch red" /> Red swarm = collection agents</span>
            <span><i className="legend-swatch yellow" /> Yellow = profitable predictions</span>
            <span><i className="legend-swatch black" /> Black cube = Kelly controller</span>
            <span><i className="legend-swatch purple" /> Purple = semantic reasoning node</span>
          </div>
        </div>

        <aside className="sidebar-stack">
          <article className="intel-card semantic-card">
            <div className="section-title">
              <Brain size={18} /> Grok-4 semantic layer
            </div>
            <p>{showSemanticPanel ? telemetry.grokInsight : 'Tap the purple node or the button above to reveal the current semantic explanation.'}</p>
            <button className="ghost-button compact" onClick={() => setShowSemanticPanel((current) => !current)}>
              {showSemanticPanel ? 'Hide' : 'Reveal'} reasoning
            </button>
          </article>

          <article className="intel-card">
            <div className="section-title">
              <DollarSign size={18} /> Kelly cube controller
            </div>
            <ul className="metric-list">
              <li><span>PPO stance</span><strong>{telemetry.regime === 'stable' ? 'Aggressive' : telemetry.regime === 'volatile' ? 'Defensive' : 'Capital preservation'}</strong></li>
              <li><span>Stake size</span><strong>{formatPercent(telemetry.kellyFraction, 2)}</strong></li>
              <li><span>Volatility penalty</span><strong>{formatPercent(telemetry.volatility, 1)}</strong></li>
            </ul>
          </article>

          <article className="intel-card">
            <div className="section-title">
              <Activity size={18} /> Swarm roster
            </div>
            <div className="agent-list">
              {sortedAgents.map(([key, config]) => (
                <div key={key} className="agent-pill" style={{ borderColor: config.color }}>
                  <span style={{ color: config.color }}>{config.icon}</span>
                  <div>
                    <strong>{config.name}</strong>
                    <small>{key.split('_').join(' ')}</small>
                  </div>
                </div>
              ))}
            </div>
          </article>
        </aside>
      </section>

      <section className="bottom-grid">
        <article className="prediction-panel">
          <div className="section-title">
            <TrendingUp size={18} /> Top live predictions
          </div>
          <div className="prediction-list">
            {orbs.length === 0 ? (
              <div className="empty-state">No live orbs right now. Hit sync to pull a fresh slate from the meta-ensemble.</div>
            ) : (
              orbs.map((orb) => (
                <PredictionCard
                  key={orb.id}
                  orb={orb}
                  active={orb.id === focusedOrb?.id}
                  onFocus={() => setFocusedOrbId(orb.id)}
                  onClaim={() => claimOrb(orb.id)}
                />
              ))
            )}
          </div>
        </article>

        <article className="prediction-panel compact-panel">
          <div className="section-title">
            <Sparkles size={18} /> Why this is demo-ready
          </div>
          <ul className="feature-list">
            <li>PWA-ready shell with manifest and offline service worker.</li>
            <li>Real POST connection to <code>/api/v2/predict</code> with mock fallback.</li>
            <li>Touch-friendly orb claiming for mobile and Android home-screen install.</li>
            <li>Live bankroll, drawdown, regime, and Kelly sizing visualization.</li>
            <li>Semantic explanation panel for trader confidence and compliance narratives.</li>
          </ul>
          <div className="notice-box">
            <AlertTriangle size={16} />
            Wire your API to return <code>predictions[]</code>, <code>regime</code>, <code>volatility</code>, and <code>grokInsight</code>.
          </div>
        </article>
      </section>
    </main>
  );
}

function PredictionCard({
  orb,
  active,
  onFocus,
  onClaim
}: {
  orb: PredictionOrb;
  active: boolean;
  onFocus: () => void;
  onClaim: () => void;
}) {
  return (
    <article className={`prediction-card ${active ? 'active' : ''}`} onMouseEnter={onFocus} onFocus={onFocus}>
      <div className="prediction-main">
        <div>
          <p className="prediction-race">{orb.race}</p>
          <h3>{orb.horse}</h3>
        </div>
        <button className="claim-button" onClick={onClaim}>
          Claim orb
        </button>
      </div>
      <div className="prediction-metrics">
        <span>Edge <strong>{orb.edge.toFixed(1)}%</strong></span>
        <span>Confidence <strong>{formatPercent(orb.confidence, 0)}</strong></span>
        <span>Odds <strong>{orb.odds.toFixed(1)}x</strong></span>
        <span>Bankroll <strong>{formatCurrency(orb.bankrollDelta)}</strong></span>
      </div>
      <p className="prediction-summary">{orb.semanticSummary}</p>
    </article>
  );
}
